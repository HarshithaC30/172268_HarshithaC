package com.petcare.delete.AddPuppiesCart.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "cart")
public class CartPojo {
	 @Id
		private String id;
	    private String uname;
	    private Customer customer;
	    
	    public CartPojo() {
	    	
	    }
		public CartPojo(String uname, Customer customer) {
			super();
			
			this.uname = uname;
			this.customer = customer;
		}
		public String getUname() {
			return uname;
		}
		public void setUname(String uname) {
			this.uname = uname;
		}
		public Customer getCustomer() {
			return customer;
		}
		public void setCustomer(Customer customer) {
			this.customer = customer;
		}
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		@Override
		public String toString() {
			return "CartPojo [uname=" + uname + ", customer=" + customer + "]";
		}
	    
}
