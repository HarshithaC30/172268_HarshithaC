package com.petcare.Puppies_creation;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PuppiesCreationApplicationTests {

	@Test
	public void contextLoads() {
	}

}
