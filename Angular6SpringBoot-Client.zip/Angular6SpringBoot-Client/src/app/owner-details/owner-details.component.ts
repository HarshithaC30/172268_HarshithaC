import { Component, OnInit, Input } from '@angular/core';
import { User } from '../user';
import { DomSanitizer } from '@angular/platform-browser';
import { UserService } from '../user.service';
import { OwnersListComponent } from '../owners-list/owners-list.component';

@Component({
  selector: 'app-owner-details',
  templateUrl: './owner-details.component.html',
  styleUrls: ['./owner-details.component.css']
})
export class OwnerDetailsComponent implements OnInit {

 /*  @Input() customer: User;
  customerList:any;
  currentCustomer:any;
 

  constructor(private customerService: UserService, private listComponent: OwnersListComponent,private _sanitizer: DomSanitizer) { }
 */
  ngOnInit() {
  }

}
