import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/cart.service';
import { Customer } from 'src/app/customer';

@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.css']
})
export class CartListComponent implements OnInit {

  carts:any;
  customer:Customer=new Customer();
    constructor(private customerService: CartService) { }
  
    ngOnInit() {
      this.reloadData();
    }

    reloadData() {
      this.customerService.getCartList().subscribe((res)=>{
        this.carts=res;
        console.log("in get all")
        console.log(res.id);
        
        console.log(res);
      })
    
   }

}
