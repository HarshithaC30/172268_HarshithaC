import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-owners-list',
  templateUrl: './owners-list.component.html',
  styleUrls: ['./owners-list.component.css']
})
export class OwnersListComponent implements OnInit {

  owners:any;

  constructor(private ownerService: UserService) { }

  ngOnInit() {
    //this.reloadData();
  }
 /*  reloadData() {
    this.ownerService.getOwnersList().subscribe((res)=>{
      this.owners=res;
      this.ownerService.saveCinfo(res);
      console.log(res);
    })
  
 } */
}
