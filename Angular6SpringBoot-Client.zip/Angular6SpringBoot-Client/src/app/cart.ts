import { Customer } from "src/app/customer";

export class Cart {
    id:number;
    uname=localStorage.getItem('uname');
    customer:any;
    
 }